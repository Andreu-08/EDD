# CURRICULUM VITAE
![Alt text](<foto para cv-1.jpg>)
## **INFORMACIÓN PERSONAL** 
**Nombre:** Andreu Orenga Ramon

**Edad:** 31

**Dirección:** C/ Plaza España nº 2, 3º pta 6

**Teléfono:** 689285949

**E-mail:** andreuorenga@gmail.com / andoreram@alu.edu.gva.es 

## **RESUMEN** 
*Tengo 10 años de experiencia en hostelería, 2 años de experiencia en industria y me encuentro cursando el módulo de desarrollo de aplicaciones web (DAW) para incorporarme a ese sector.*

## **EXPERIENCIA LABORAL**
### **Giuliani's Salera**
*Responsable sección pizzería durante 3 años.*
### **Pizzeria Olivo**
*Cocinero especializado en pizzería durante 3 años.*
### **L'Horta Cuina Conscient** 
*Segundo de cocina/Cocinero encargado del correcto funcionamiento de la cocina y ayudante de la gestión de pedidos. 3 años.*
### **Azulejera Stylnul**
*Operario en la sección de clasificación de azulejos durante 6 meses.*
### **Aquabella/Construplas**
*Operario de cabinas de pintura y fabricación de platos de ducha durante 2 años.*

# ESTUDIOS
- Educación Secundaria Obligatoria, *IES Botánic Cabanilles*.
- FP Grado Medio Hostelería y Cocina, *CIPFP COSTA DE AZAHAR*.
- Título Bachiller por prueba de acceso a la universidad para mayores de 25, *IES Jordi de San Jordi*.
- Cursando actualmente FP Superior Desarrollo de Aplicaciones Web, *IES Benigasló*.

# HABILIDADES
- Facilidad de adaptación al trabajo en equipo.
- Iniciativa a la hora de resolver problemas.

# IDIOMAS
- Castellano, oral y escrito.
- Valenciano, oral y escrito.
- Inglés, nivel básico (ESO/Bachiller).

# INTERESES
### Profesionales 
*Actualmente interesado en todo lo relacionado con el mundo de la informática, la tecnología y el desarrollo web.*

### Personales 
- Deporte.
- Viajes.
- Libros.

