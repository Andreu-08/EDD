package src;
public interface Retrollamada {
    void llamar();
}